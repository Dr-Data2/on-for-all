#!/usr/bin/python 
from bin.Desk import *
from bin.password import *
from bin.o2 import *
from bin.scanning import *
from bin.ARat import a_rat
from bin.Error import error
from time import sleep
from bin.Exite import exite
from bin.ddos import Ddos
from bin.ddos1 import Ddos1
from bin.ddos2 import Ddos2
from bin.RED_HAWK import red
from bin.hui_server import hui 
from bin.Beef import beef
from bin.banner import one
from bin.meta import *
from bin.Hydra import hydra
from bin.wifite2 import wifite
from bin.banners import *
#----------imports---------
import sys,os
b='\033[;94m'
r='\033[1;31m'
p="💀"
w="\033[0m"
#Void()
class list():
		def run(self):
			os.system("clear")
			sem()
			O()
			x11 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main{b}]
{b} └─{r}# {w}""")
			if x11 == "1":
				self.OO()
			elif x11 == "2":
				self.passwords()
			elif x11 == "3":
				self.scan()
			elif x11 == "4":
				self.exploit()
			elif x11 == "5":
				self.fishing()
			elif x11 == "6":
				print("h1")
			elif x11 == "7":
				self.info()
			elif x11 == "8":
				self.tools_kali()
			elif x11 == "9":
				self.Virus()
			elif x11 == "99":
			            exite()
			else :
			            error()
			            sleep(0.5)
			            self.run()
		def exploit(self):
			os.system("clear")
			sleep(0.5)
			sem()
			O2()
			
			x1 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Exploit{b}]
{b} └─{r} #{w}""")
			if x1 == '1' :
				Metasploit()
				sleep(2)
				self.exploit()
			elif x1 == '2':
				a_rat()
				sleep(2)
				self.exploit()
			elif x1 == '3' :
				pshmode()
				sleep(2)
				self.exploit()
			elif x1 == '4' :
				MetasploitNoRoot()
				sleep(2)
				self.exploit()
			elif x1 == '5':
				commix()
				sleep(2)
				self.exploit()
			elif x1 == '6':
				sqlmap()
				sleep(2)
				self.exploit()
			elif x1 == '7':
				brutal()
				sleep(2)
				self.exploit()
			elif x1 == '8':
				wpsploit()
				sleep(2)
				self.exploit()
			elif x1 == '9':
				routersploit()
				sleep(2)
				self.exploit()
			elif x1 == '10':
				blackBox()
				sleep(2)
				self.exploit()
			elif x1 == '11':
				xattacker()
				sleep(2)
				self.exploit()
			elif x1 == '12':
				txtool()
				sleep(2)
				self.exploit()
			elif x1 == "13":
				msfpg()
				sleep(2)
				self.exploit()
			elif x1 == "14":
				asu()
				sleep(2)
				self.exploit()
			elif x1 == '00':
				self.run()
			else :
				error()
				sleep(0.5)
				self.exploit()
		def passwords(self):
			os.system("clear")
			sem()
			O3()
			x0 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Attack Password{b}]
{b} └─{r} #{w}""")
			if x0== '1' :
				hydra()
				sleep(2)
				self.passwords()
			elif x0 == '2':
				fmbrute()
				sleep(2)
				self.passwords()
			elif x0 == '3':
				hashid()
				sleep(2)
				self.passwords()
			elif x0 == '4':
				fbBrute()
				sleep(2)
				self.passwords()
			elif x0 == '5':
				fbbrutex()#عدله بعدين
				sleep(2)
				self.passwords()
			elif x0 == '6':
				fbbrutex()
				sleep(2)
				self.passwords()
			elif x0 == '7':
				cupp()
				sleep(2)
				self.passwords()
			elif x0 == '8':
				instaHack()
				sleep(2)
				self.passwords()
			elif x0 == '9':
				indonesian_wordlist()
				sleep(2)
				self.passwords()
			elif x0 == '10':
				xshell()
				sleep(2)
				self.passwords()
			elif x0 == '11':
				social()
				sleep(2)
				self.passwords()
			elif x0 == '12':
				blackbox()
				sleep(2)
				self.passwords()
			elif x0 == '13':
				hashzer()
				sleep(2)
				self.passwords()
			elif x0 == '14':
				hasher()
				sleep(2)
				self.passwords()
			elif x0 == '15':
				hashgenerator()
				sleep(2)
				self.passwords()
			elif x0 == '16':
				nk26()
				sleep(2)
				self.passwords()
			elif x0 == '17':
				hasherdotid()
				sleep(2)
				self.passwords()
			elif x0 == '18':
				crunch()
				sleep(2)
				self.passwords()
			elif x0 == '19':
				hashcat()
				sleep(2)
				self.passwords()
			elif x0 == '20':
				asu()
				sleep(2)
				self.passwords()
			elif x0 == '00':
		                self.run()
			else :
		                error()
		                sleep(0.5)
		                self.passwords()

		def OO(self):
			os.system("clear")
			sem()
			O1()
			xx= input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/OS{b}]
{b} └─{r}# {w}""")
			if xx == '1' :
				kali()
				sleep(2)
				self.OO()
			elif xx == '2' :
				ubuntu()
				sleep(2)
				self.OO()
			elif xx == '3':
				arch()
				sleep(2)
				self.OO()
			elif xx == '4' :
				debian()
				sleep(2)
				self.OO()
			elif xx == '5' :
				manjaro()
				sleep(2)
				self.OO()
			elif xx == '6' :
				alpine()
				sleep(2)
				self.OO()
			elif xx == '7' :
				fedora()
				sleep(2)
				self.OO()
			elif xx == '8' :
				nethunter()
				sleep(2)
				self.OO()
			elif xx == '00' :
				self.run()
			else : 
				error()
				sleep(0.5)
				self.OO()
			list()
		def scan(self):
			sem()
			O5()
			x3 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Scan{b}]
{b} └─{r}# {w}""")
		
			if x3 == '1' :
				nmap()
				sleep(2)
				self.scan()
			elif x3 == '2' :
				red_hawk()
				sleep(2)
				self.scan()
			elif x3 == '3' :
				androZenmap()
				sleep(2)
				self.scan()
			elif x3 == '4' :
				astraNmap()
				sleep(2)
				self.scan()
			elif x3 == '5' :
				easyMap()
				sleep(2)
				self.scan()
			elif x3 == '6' :
				dtect()
				sleep(2)
				self.scan()
			elif x3 == '7' :
				sqliv()
				sleep(2)
				self.scan()
			elif x3 == '8' :
				sqlscan()
				sleep(2)
				self.scan()
			elif x3 == '9' :
				wordpreSScan()
				sleep(2)
				self.scan()
			elif x3 == '10' :
				wpscan()
				sleep(2)
				self.scan()
			elif x3 == '11' :
				wordpresscan()
				sleep(2)
				self.scan()
			elif x3 == '12' :
				sqlmate()
				sleep(2)
				self.scan()
			elif x3 == '13' :
				wtf()
				sleep(2)
				self.scan()
			elif x3 == '14' :
				rang3r()
				sleep(2)
				self.scan()
			elif x3 == '15' :
				striker()
				sleep(2)
				self.scan()
			elif x3 == '16' :
				routersploit()
				sleep(2)
				self.scan()
			elif x3 == '17' :
				xshell()
				sleep(2)
				self.scan()
			elif x3 == '18' :
				sh33ll()
				sleep(2)
				self.scan()
			elif x3 == '19' :
				blackbox()
				sleep(2)
				self.scan()
			elif x3 == '20' :
				xattacker()
				sleep(2)
				self.scan()
			elif x3 == '21' :
				owscan()
				sleep(2)
				self.scan()
			elif x3 == '22':
				print("hacker mode") #عدله بعدين
				sleep(2)
				self.scan()
			elif x3 == '23':
				nikto()
				sleep(2)
				self.scan()
			elif x3 == '00':
		                self.run()
			else :
		                error()
		                sleep(0.5)
		                self.scan()
		
		def fishing(self):
			sem()
			O6()
			x4 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Fishing{b}]
{b} └─{r}# {w}""")
			if x4 == '1' :
				hui()
				sleep(5)
				self.fishing()
			elif x4 == '2' :
				wishfish()
				sleep(2)
				self.fishing()
			elif x4 == '3' :
				saycheese()
				sleep(2)
				self.fishing()
			elif x4 == '4' :
				zphisher()
				sleep(2)
				self.fishing()
			elif x4 == '00':
				self.run()
			else :
		                error()
		                sleep(0.5)
		                self.fishing()
		def utility(self):
			x5 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Termux Utility{b}]
{b} └─{r}# {w}""")
			if x5 == '1' :
				print("drdata")
			elif x5 == '00':
		                self.run()
			else :
		                error()
		                sleep(0.5)
		                self.utility()
		
		def info(self):
			sem()
			O7()
			x7 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/information Gatring{b}]
{b} └─{r}# {w}""")
			if x7 == '1':
				namp()
				sleep(2)
				self.info()
			elif x7 == '2':
				red_hawk()
				sleep(2)
				self.info()
			elif x7 == '3':
				dtect()
				sleep(2)
				self.info()
			elif x7 == '4':
				sqlmap()
				sleep(2)
				self.info()
			elif x7 == '5':
				infoga()
				sleep(2)
				self.info()
			elif x7 == '6':
				reconDog()
				sleep(2)
				self.info()
			elif x7 == '7':
				androZenmap()
				sleep(2)
				self.info()
			elif x7 == '8':
				sqlmate()
				sleep(2)
				self.info()
			elif x7 == '9':
				astraNmap()
				sleep(2)
				self.info()
			elif x7 == '10':
				wtf()
				sleep(2)
				self.info()
			elif x7 == '11':
				easyMap()
				sleep(2)
				self.info()
			elif x7 == '12':
				xd3v()
				sleep(2)
				self.info()
			elif x7 == '13':
				crips()
				sleep(2)
				self.info()
			elif x7 == '14':
				sir()
				sleep(2)
				self.info()
			elif x7 == '15':
				 xshell()
				 sleep(2)
				 self.info()
			elif x7 == '16':
				evilURL()
				sleep(2)
				self.info()
			elif x7 == '17':
				striker()
				sleep(2)
				self.info()
			elif x7 == '18':
				maxsubdofinder()
				sleep(2)
				self.info()
			elif x7 == '19':
				fim()
				sleep(2)
				self.info()
			elif x7 == '20':
				asu()
				sleep(2)
				self.info()
			elif x7 == '21':
				gpstr()
				sleep(2)
				self.info()
			elif x7 == '22':
				ginf()
				sleep(2)
				self.info()
			elif x7 == '23':
				inther()
				sleep(2)
				self.info()
			elif x7 == '24':
				 auxile()
				 sleep(2)
				 self.info()
			elif x7 == '25':
				namechk()
				sleep(2)
				self.info()
			elif x7 == '26':
				devploit()
				sleep(2)
				self.info()
			elif x7 == '27':
				osif()
				sleep(2)
				self.info()
			elif x7 == '28':
				owscan()
				sleep(2)
				self.info()
			elif x7 == '00':
				self.run()
			else :
			               error()
			               sleep(0.5)
			               self.info()
		def tools_kali(self):
			sem()
			O8()
			x7 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Tools Kali{b}]
{b} └─{r}# {w}""")
			if x7 == '1':
				print("Moon John")
				sleep(2)
				self.tools_kali()
			elif x7 == '2' :
				hydra()
				sleep(2)
				self.tools_kali()
			elif x7 == '3' :
				print("moon Armitage .....")
				sleep(2)
				self.tools_kali()
			elif x7 == '4' :
				beef()
				sleep(2)
				self.tools_kali()
#			elif x7 == '6' :
#				print("burpsuite")
#				sleep(2)
#				self.tools_kali()
			elif x7 == '5' :
				wifite()
				sleep(2)
				self.tools_kali()
			elif x7 == '6' :
				nikto()
				sleep(2)
				self.tools_kali()
			elif x7 == '00':
			       self.run()
		        
			else :
		                error()
		                sleep(0.5)
		                self.tools_kali()	
		def Virus(self):
			sem()
			O9()
			x8 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Virus{b}]
{b} └─{r}# {w}""")
			if x8 == '1' :
				self.Vandroid()
			elif x8 == '2' :
				self.Vlinux()
			elif x8 == '3' :
				self.Vwin()
			elif x8 == '4' :
				self.Vwhat()
			elif x8 == '00':
		                self.run()
		        
			else :
		                error()
		                sleep(0.5)
		                self.Virus()
		def Vandroid(self):
			sem()
			O91()
			x91= input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Virus/android{b}]
{b} └─{r}# {w}""")
			if x91 == '1':
				vn1()
			elif x91 == '2':
				vn2()
			elif x91 == '3':
				vn3()
			elif x91 == '4':
				vn4()
			elif x91 == '5':
				vn5()
			elif x91 == '6':
				vn6()
			elif x91 == '00':
				self.Virus()
			else:
			               error()
			               sleep(0.5)
			               self.Vandroid()
		def Vlinux(self):
			sem()
			O92()
			x92 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Virus/Linux{b}]
{b} └─{r}# {w}""")
			if x92 == '1':
				vl1()
			elif x92 == '2':
				vl2()
			elif x92 == '00':
				self.Virus()
			else:
			               error()
			               sleep(0.5)
			               self.Vlinux()
		def Vwin(self):
			sem()
			O93()
			x93 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Virus/windows{b}]
{b} └─{r}# {w}""")
			if x93 == '1':
				vw1()
			elif x93 == '2':
				vw2()
			elif x93 == '3':
				vw3()
			elif x93 == '3':
				vw3()
			elif x93 == '4':
				vw4()
			elif x93 == '5':
				vw5()
			elif x93 == '6':
				vw6()
			elif x93 == '7':
				vw7()
			elif x93 == '00':
				self.Virus()
			else:
			               error()
			               sleep(0.5)
			               self.Vwin()
		def Vwhat(self):
			sem()
			O94()
			x94 = input(f"""{b} ┌──(  {r}OneF{p}rAlll{b})-[{r}Main/Virus/WhatsApp{b}]
{b} └─{r}# {w}""")
			if x94 == '1':
				v1()
			elif x94 == '2':
				v2()
			elif x94 == '3':
				v3()
			elif x94 == '4':
				v4()
			elif x94 == '5':
				v5()
			elif x94 == '6':
				v6()
			elif x94 == '7':
				v7()
			elif x94 == '8':
				v8()
			elif x94 == '9':
				v9()
			elif x94 == '10':
				v10()
			elif x94 == '11':
				v11()
			elif x94 == '12':
				v12()
			elif x94 == '13':
				v13()
			elif x94 == '00':
				self.Virus()
			else:
			               error()
			               sleep(0.5)
			               self.Vwhat()
if __name__ == '__main__':
		os.system("clear")
		#one()	
		#list = list()
		#os.system("clear")
		list().run()
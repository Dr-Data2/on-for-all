# One For All

[![YouTube Channel Subscribers](https://img.shields.io/youtube/channel/subscribers/UCDCHcqyeQgJ-jVSd6VJkbCw?logo=youtube&logoColor=red&style=for-the-badge)][youtube]
[![Website](https://img.shields.io/website?label=codeSTACKr.com&style=for-the-badge&url=https%3A%2F%2Fcodestackr.com)](https://codestackr.com)
[![Telegram](https://t.me/kali_linux_ar)
Download Termux tools without problems with download android and lots of operating systems
![Image 1](https://raw.githubusercontent.com/mr-sami-x/admin-ye/main/PicsArt_04-05-03.17.28~2.png)
## installing

- 1 . <code> pkg install python </code>
- 2 . <code> git clone url </code>
- 3 . <code> cd oneforall </code>
- 4 . <code> bash install.sh </code>
- 5 . <code> one </code>
### Connect with me:

[![website](./img/youtube-light.svg)](https://youtube.com/codestackr#gh-light-mode-only)
[![website](./img/youtube-dark.svg)](https://youtube.com/codestackr#gh-dark-mode-only)
&nbsp;&nbsp;

### Languages and Tools:

[<img align="left" alt="Git" width="26px" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" style="padding-right:10px;" />][webdevplaylist]
[<img align="left" alt="GitHub" width="26px" src="https://user-images.githubusercontent.com/3369400/139447912-e0f43f33-6d9f-45f8-be46-2df5bbc91289.png" style="padding-right:10px;" />](https://www.youtube.com/playlist?list=PLkwxH9e_vrAJ0WbEsFA9W3I1W-g_BTsbt#gh-dark-mode-only)
[<img align="left" alt="GitHub" width="26px" src="https://user-images.githubusercontent.com/3369400/139448065-39a229ba-4b06-434b-bc67-616e2ed80c8f.png" style="padding-right:10px;" />](https://www.youtube.com/playlist?list=PLkwxH9e_vrAJ0WbEsFA9W3I1W-g_BTsbt#gh-light-mode-only)
[<img align="left" alt="Terminal" width="26px" src="./img/terminal-light.svg" />](https://www.youtube.com/playlist?list=PLkwxH9e_vrAJ0WbEsFA9W3I1W-g_BTsbt#gh-light-mode-only)
[<img align="left" alt="Terminal" width="26px" src="./img/terminal-dark.svg" />](https://www.youtube.com/playlist?list=PLkwxH9e_vrAJ0WbEsFA9W3I1W-g_BTsbt#gh-dark-mode-only)

<br />
<br />

---

### 📺 Latest YouTube Videos

<!-- YOUTUBE:START -->
- [Fastest Upgrade to React 18!! Only 1 Second! 🤯](https://www.youtube.com/watch?v=JLyVyURIWG0)
- [5 Reasons You Should NOT Create an NFT Collection!!](https://www.youtube.com/watch?v=1ktrrwasouc)
- [Do You Need To Know Web Dev To Become A Web3 Developer? With Hashlips](https://www.youtube.com/watch?v=oQBRZMo0e34)
- [BEST Mint From Site &lpar;dapp&rpar; - Entire Process! Whitelist &amp; Launch an NFT Collection &lpar;10,000+&rpar;](https://www.youtube.com/watch?v=cLB7u0KQFIs)
- [ULTIMATE Create An ENTIRE NFT Collection &lpar;10,000+&rpar; &amp; MINT With ZERO Coding Knowledge - PFP Generator](https://www.youtube.com/watch?v=quGdJweadFM)
<!-- YOUTUBE:END -->

➡️ [more videos...](https://youtube.com/codestackr)

---

### 📕 Latest Blog Posts

<!-- BLOG-POST-LIST:START -->
- [How install NetHanter in Termux](https://kalilnuxar.blogspot.com/2022/02/kali-nethanter-not-root.html?m=1)
- [How install Metasploit No Root in Termux](https://kalilnuxar.blogspot.com/2022/01/metasploit-no-root.html?m=1)
- [Explain a tool PSHMode ](https://kalilnuxar.blogspot.com/2022/01/pshmode.html?m=1)
<!-- BLOG-POST-LIST:END -->

➡️ [more blog posts...](https://kalilnuxar.blogspot.com/?m=1)

---

<details>
  <summary>:zap: Recent GitHub Activity</summary>
  
<!--START_SECTION:activity-->
Sections
1. 🐧 os  
2. 🕸 Virus 
3. 🎯 password  
4. 🤺 Attack phone 
5. 🦂 Exploit Tools 
6. 🌹 Termux Utility
7. 🎄 Termux Design 
8. 📛 Wireless Attacks
9. 🚫 DDos Attack

<!--END_SECTION:activity-->

</details>

<details>
  <summary>:zap: GitHub Stats</summary>

  <img align="left" alt="codeSTACKr's GitHub Stats" src="https://github-readme-stats.vercel.app/api?username=codeSTACKr&show_icons=true&hide_border=false&title_color=ff652f&icon_color=FFE400&bg_color=09131B&text_color=ffffff&border_color=0c1a25" />

</details>

[website]: https://codeSTACKr.com
[youtube]: https://youtube.com/codeSTACKr
[webdevplaylist]: https://www.youtube.com/playlist?list=PLkwxH9e_vrAJ0WbEsFA9W3I1W-g_BTsbt
[jsplaylist]: https://www.youtube.com/playlist?list=PLkwxH9e_vrALRJKu7wfXby3MKeflhTu6B
[cssplaylist]: https://www.youtube.com/playlist?list=PLkwxH9e_vrALSdvZuEh6gqQdmDoDIoqz4
[reactplaylist]: https://www.youtube.com/playlist?list=PLkwxH9e_vrAK4TdffpxKY3QGyHCpxFcQ0

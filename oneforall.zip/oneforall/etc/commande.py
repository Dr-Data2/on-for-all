#!/usr/bin/python

def com():
	x = input("Enter >> ")

	import subprocess

	process_1 = subprocess.run(x,shell=True)
	print(process_1)
while True:
	com()

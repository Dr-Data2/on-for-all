import os

path = "/data/data/com.termux/files/home/oneforall/etc/command.py"
os.chmod(path)

import os
import json 

class commands:
	def command(self):
		commande = input("OFA >> ")
		commande = command.split("")
		print(commande)
	def rellable(self,data):
		json_data = json.dumps(data)
		self.command(json_data)

	def reliable_reseive(self):
		json_data = self.command()
		return json.loads(json_data)
	def execute_system_command(self):
		if command[0] == "exit":
			exit()
	def run(self):
		while True:
			command = self.reliable_reseive()
			command_result = execute_system_command(command)
			self.result_send(command_result)
		x.close()
comm = commands()
comm.run()

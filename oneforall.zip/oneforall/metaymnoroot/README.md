# metaymnoroot
تنزيل الميتا بدون صلاخية روت

import os
import sys
from time import sleep
G = '\033[32m'  # green
R = '\033[31m'  # red
def asss():
    os.system('clear')
    
    sleep(1)
    print ( G +'''   /+ss+.:/:-``  ` ```````````.`    ` `.-.` `       ```
:yhyd-::-``  `.` `.`    `.` ```----.``                  .. `
/os+o  ```/. `..``+y--dyyMyoNyhh:::::../.os`  .. :h/.hmsMm/M
sdyh/`o/m+MM+m-MN+MMshMNNNyyNmmmdNdh/oNMsmMyd:NM+MMmoMMMMMNM
yNmMm/MyNoMMoM+MMoNNNNNNNMyymNNNmMMNymNMyNMsm+MM+MMMMMMMMMMM
yNMMMoMMMNMMNM+MMNMMNNNMMMysmNNMNNNNhNMNNMMMM+MMMMMMMMMMMMMM
mMMMMMMMMMMMMMoMMMMNNMMNMMsmNNMMMNMNMMMMNMMMMoMMMMMMMMMMMMMM
MMMMMMMMMMMMMMyMMMNNNNNMMmoMNMNNNNMNNMMMMNMMMhMMMMMMMMMMMMMM
MMMMMMMMMMMMMmNNNNNNNNNMMhmNNMNNNNNMNMMMNMNMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMNNNNMNNNMdNNNmNmNNMNmNNNMNNMNNMNMMMMMMMMMMMMMMMM
MMMMMMMMMMMMNNNMNNNNNmNNNNNdNNMNhNmNNNNNMNNNMMMMMMMMMMMMMMMM
MMMMMMMMMMMNsmNNNmNmsNNmmdNyNmNNdmdhmNNmNNmNNMMMMMMMMMMMMMMM
MMMMMMMMMMNdmNNNmdNdNmm+m+mmNNNNddysyhmyNNmdNMMMMMMMMMMMMMMM
MMMMMMMMMMMNhmmNmhhmmdy/dodmNdNm/oydsomdmNmyNMMMMMMMMMMMMMMM
MMMMMMMMMMMmmsdddh/ho+/osyydym+h//ohy+ddymdsdMMMMMMMMMMMMMMM
MMMMMMMMMMMMm+:sys--.`.::+:d+dyo++/so+mdoddymMMMMMMMMMMMMMMM
MMMMMMMMMMMMdo:+//-`..:.-:/shyhyyoydhydyyhyNMMMMMMMMMMMMMMMM
MMMMMMMMMMMMdhMo/o+`.--..-/-/:/oyhmNNmyhs+dNMMMMMMMMMMMMMMMM
mymMMMMdmMMMNNNymhs-..--..``-....-hoohhydNdoyNMomMNdMMmmMyNM
MsNMsoMysNNohMoyMdd/.-.:````:.::.o/..yhhMMM+omNssMyomNosMsNM
MhMMddMdhNM+NMhhMmd/:...osoooosyo.:.ohyhMMMmhNMmyMNhMMdmMmMM
MMMMMMMMMMMNMMMMMMNdy/`--+yhhhys:..oydNNMMMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMmhhNy:--```.-:o:-...-::.`/NMMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMy``.+-..````.-o.```..-````-yNMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMN:``````.`````````-.`````..:NMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMM+```````.`````````..```...:NMMMMMMMMMMMMMMMMM
MMMMMMMMMMMMMMMd`````````````````````.```:hMMMMMMMMMMMMMMMMM
MMMMMMMMMm//++:-/sdNmho/-`.`````````````...+mMMMMMMMMMMMMMMM
NMMMNmsshsy-.ydNNmmmhhdmNh-...`````..........:yNMMMMMMMMMMMM
/-:-..``.sdh+NmmNMNNNmy.-oy:``````............`so.-///oydmNM
:......```+hmmmNNNNNNNdhsos/-..................s/.......`-dd
-``.....````dNNNmdmmmNmNNmhdd:.................o........`..+
-````.....`.NMMmMNNNms/+hmy.--....```````..................s
.`````.....+NMMNNddy+....:ss:.........``````..`.``......``.y
.``````...`dMMNNddhy:.........`..........````````....````.`h
.```````..:MMNNmddhy..........``............```````.`````..o
.````````.yMMNmhsdy:........`..``.............```````````...
.````````-MMNmdyoh-.........`...```............`.```````....
.````````+mNdddso-..`.`````.``.`.``.........``````````````..
.```````-dNmhodo.```````````````````....`..```````````````.`
.```````::ddyoh+````````  `````.`` ````.```` `` ```````  ```
.`` `` `-.os:-`    `          ```` `` ``  `
...`  `----....                                   `...`''')
    sleep(2)
    print("\n****************************************************************")
    sleep(.5)
    print("\n* Hacker BE Dr.Data and ALASTORH ,,   STORMUOS and Hacker from Yemen                             *")
    sleep(.5)
    print("\n* https://t.me/khkbu  + and +  https://t.me/HACKER2222hc         *")
    sleep(.5)
    print("\n* https://youtu.be/UOPN02kNagY                         *")
    sleep(.5)
    print("\n****************************************************************")
    sleep(.25)
    print ('********************* y starting ******************\n')
    sleep(.5)
    print("****************************************************************\n\n")
    sleep(1)
    print (" +++     METASPLOIT NO ROOT V 6    +++  \n")
   # oo=input(" ××× Enter your (y) To follow upload to metasploit (n) Stop ......?")

def runn():
	print ("++ starting ++")
	os.system("pkg update && pkg upgrade")
	os.system("pkg install postgresql")
	print(R +"""
	.                                                      .
      .n                     .             .                n.
  . .dP                   dP               9b               9b   .
 4  qXb         .        dX                 Xb       .      dXp   t
dX.  9Xb      .dXb     __                     __    dXb.   dXP   .Xb
9XXb._     _.dXXXXb dXXXXbo.               dXXXXb dXXXXb._   _.dXXP
 9XXXXXXXXXXXXXVXXXXXXXXOo.           .oOXXXXXXXXVXXXXXXXXXXXXXXXP
   9XXXXXXXXXXXXXXX ~   ~ OOO8b   d8OOO ~   ~ XXXXXXXXXXXXXXXXXP
     9XXXXXP   9XX      *     98v8P      *     XXP   9XXXXXXXP
      ~~~       9X.          .db|db.          .XP       ~~~
                  )b.  .dbo.dP' v  9b.odb.  .dX(
                ,dXXXXXXXXXXXb     dXXXXXXXXXXXb.
               dXXXXXXXXXXXP'   .    9XXXXXXXXXXXb
              dXXXXXXXXXXXXb   d|b   dXXXXXXXXXXXXb
              9XXb'    XXXXXb.dX|Xb.dXXXXX'    dXXP
                       9XXXXXX(   )XXXXXXP
                       XXXX X. v .X XXXX
                        XP^X' b   d' X^XX
                        X. 9         P )X
                         b          '  d'
	
	""")
	os.system("pkg install openssh wget curl git -y")
	print(R +"""
	____                                                       __,---'     `--.__
                           ,-'                ; `.
                          ,'                  `--.`--.
                         ,'                       `._ `-.
                         ;                     ;     `-- ;
                       ,-'-_       _,-~~-.      ,--      `.
                       ;;   `-,;    ,'~`.__    ,;;;    ;  ;
                       ;;    ;,'  ,;;      `,  ;;;     `. ;
                       `:   ,'    `:;     __/  `.;      ; ;
                        ;~~^.   `.   `---'~~    ;;      ; ;
                        `,' `.   `.            .;;;     ;'
                        ,',^. `.  `._    __    `:;     ,'
                        `-' `--'    ~`--'~~`--.  ~    ,'
                       /;`-;_ ; ;. /. /   ; ~~`-.     ;
-._                   ; ;  ; `,;`-;__;---;      `----'
   `--.__             ``-`-;__;:  ;  ;__;
 ...     `--.__                `-- `-'
`--.:::...     `--.__                ____
    `--:::::--.      `--.__    __,--'    `.
        `--:::`;....       `--'       ___  `.
            `--`-:::...     __           )  ;
                  ~`-:::...   `---.      ( ,'
                      ~`-:::::::::`--.   `-.
                          ~`-::::::::`.    ;
                              ~`--:::,'   ,'
                                   ~~`--'~
	
	""")
	os.system("wget https://raw.githubusercontent.com/gushmazuko/metasploit_in_termux/master/metasploit.sh")
	os.system("chmod 777 metasploit.sh")
	print(R +"""
	´´´´´´´$                      $´´´´´´´
       ´´´´´´$$      Created by      $$´´´´´´
       ´´´´´´$$                      $$´´´´´´
       ´´´´´´´$$s  @@HACKER2222hc  s$$´´´´´´´
       ´´´´´´´´$$$$              $$$$´´´´´´´´
       ´´´´´´´´´³$$$$´¶¶¶¶¶¶¶¶´$$$$³´´´´´´´´´
       ´´´´´´´´´´³$$$$´¶¶¶¶¶¶´$$$$³´´´´´´´´´´
       ´´´´´´´´´¶´$$$$$´¶¶¶¶´$$$$$´¶´´´´´´´´´
       ´´´´´´´´¶¶¶´$$$´¶¶¶¶¶¶´$$$´¶¶´´´´´´´´´
       ´´´´´´´´¶¶¶¶¶´´¶¶¶¶¶¶¶¶´´¶¶¶¶´´´´´´´´´
       ´´´´´´´´¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶´´´´´´´´´
       ´´´´´´´´´´¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶¶´´´´´´´´´
       ´´´´´´´´´´¶¶´´´´¶¶¶¶´´´´´¶´´´´´´´´´´´´
       ´´´´´´´´´´¶¶´´´´¶¶¶¶´´´´´¶¶´´´´´´´´´´´
       ´´´´´´´´´´¶¶¶¶¶¶¶¶´¶¶¶¶¶¶¶¶´´´´´´´´´´´
       ´´´´´´´´´´´¶¶¶¶¶¶´´´¶¶¶¶¶¶¶´´´´´´´´´´´
       ´´´´´´´´´´´´´´¶¶¶¶¶¶¶¶¶´´´´´´´´´´´´´´´
       ´´´´´´´´´´´´´´¶´¶´¶´¶´¶´´´´´´´´´´´´´´´
       ´´´´´´¶´´´´´´´¶´´´´´´´¶´´´´´´´¶´´´´´´´
       ´´´´´¶¶´´´´´´´´´´´´´´´´´´´´´´´¶¶´´´´´´
       ´´´´´¶¶´´´´´´´´¶´´´´´¶´´´´´´´´¶¶´´´´´´
       ´´´´´¶¶´´´´´´´¶¶´´´´´¶¶´´´´´´´¶¶´´´´´´
       ´´´´´¶¶´¶¶´¶¶´¶´´´´´´´¶´¶¶´¶¶´¶¶´´´´´´
       ´´´¶´¶¶´¶¶´¶¶´¶´´´´´´´¶´¶¶´¶¶´¶¶´¶´´´´
       ´´¶¶´¶¶´¶¶´¶¶´¶´´´´´´´¶´¶¶´¶¶´¶¶´¶¶´´´
       ´´´¶¶¶¶´¶¶´¶¶´´´´´´´´´´´¶¶´¶¶´¶¶¶¶´´´´
       ´´´´¶¶¶¶¶¶¶¶¶´´´´´´´´´´´¶¶´¶¶´¶¶¶´´´´
	
	""")
	os.system("./metasploit.sh")
	print ("\n\n +++  ×××  msfconsole  ××× +++ \n\n ")
	print( G + """
     .---. one for all  .------ALASTORH----------
               /     \  __  /    ---DR.DATA---
              / /     \(  )/    ------
             //////   ' \/ `   ----
            //// / // :    : ----
           // /   /  /`    '---
          //          //..\\
        =============UU====UU====
                     '//||\\`
                       ''``
""")

    
asss()
oo=input(" ××× Enter your (y) To follow upload to metasploit (n) Stop ......?  ")
if oo == "y":
	runn()